<?php
// Start the session and ensure the user is logged in
session_start();
if (!isset($_SESSION["studentloggedin"]) || $_SESSION["studentloggedin"] !== true) {
    header("location: studentlogin.php");
    exit;
}

// Get the roll number from the session
$rollnumber = $_SESSION["rollnumber"];

// Include database connection
include "database.php";

// Fetch the quiz results for the logged-in student
$stmt = $conn->prepare("SELECT quiznumber, totalmarks, maxmarks FROM result WHERE rollnumber = ?");
$stmt->bind_param("i", $rollnumber);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Results</title>
    <link rel="stylesheet" href="style.css"> <!-- Link to your existing CSS file -->
</head>
<body>
    <div class="container">
        <h1>Your Quiz Results</h1>
        <table>
            <thead>
                <tr>
                    <th>Quiz ID</th>
                    <th>Score</th>
                    <th>Max Marks</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Display the quiz results in a table
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                                <td>" . $row["quiznumber"] . "</td>
                                <td>" . $row["totalmarks"] . "</td>
                                <td>" . $row["maxmarks"] . "</td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='3'>No quiz results found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
// Close the statement and database connection
$stmt->close();
$conn->close();
?>
