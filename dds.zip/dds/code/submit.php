<?php
session_start();
if(!isset($_SESSION["studentloggedin"]) || $_SESSION["studentloggedin"] !== true){
    header("location: studentlogin.php");
    exit;
}

$rollnumber = $_SESSION["rollnumber"];
$totalques = $_SESSION["numques"];
$quiznumber = $_SESSION["quiznumber"];
include "database.php";

// Initialize total marks
$totalMarks = 0;

// Fetch the student's answers and correct answers
for ($i = 1; $i <= $totalques; $i++) {
    if (isset($_POST["answer_" . $i])) {
        $studentAnswer = $_POST["answer_" . $i]; // Assuming form inputs are named as answer_1, answer_2, etc.

        // Adjusted query to fetch correct answers from the `dropdown` table
        $sql = "SELECT answer FROM dropdown WHERE id = $i;";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $correctAnswer = $row["answer"];

            // Compare student's answer with the correct answer
            if ($studentAnswer == $correctAnswer) {
                $totalMarks++; // Increment marks for correct answer
            }
        }
    }
}

// Fetch max marks for the quiz
$sql = "SELECT maxmarks FROM quizconfig WHERE quiznumber = $quiznumber;";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$maxmarks = $row["maxmarks"];

// Update the result table with the total marks
$sql = "INSERT INTO result (rollnumber, quiznumber, submit, maxmarks, totalmarks) 
        VALUES ($rollnumber, $quiznumber, 1, $maxmarks, $totalMarks)
        ON DUPLICATE KEY UPDATE totalmarks = $totalMarks, submit = 1;";
$result = $conn->query($sql);

header("Location: studentlogout.php");
?>
