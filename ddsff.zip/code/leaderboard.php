<?php
session_start();
if(!isset($_SESSION["instructorloggedin"]) || $_SESSION["instructorloggedin"] !== true){
    header("location: instructorlogin.php");
    exit;
}

include "database.php";

// Fetch leaderboard data
$sql = "
    SELECT 
        rollnumber, quiznumber, totalmarks, maxmarks, 
        CASE 
            WHEN maxmarks > 0 THEN (totalmarks / maxmarks * 100)
            ELSE 0
        END AS percentage 
    FROM 
        result 
    WHERE 
        submit = 1 
    ORDER BY 
        percentage DESC, totalmarks DESC
";

$result = $conn->query($sql);

// HTML structure for the leaderboard
echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leaderboard</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Quiz Leaderboard</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Roll Number</th>
                <th>Quiz Number</th>
                <th>Total Marks</th>
                <th>Max Marks</th>
                <th>Percentage</th>
            </tr>
        </thead>
        <tbody>';

// Display leaderboard data
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>{$row['rollnumber']}</td>
            <td>{$row['quiznumber']}</td>
            <td>{$row['totalmarks']}</td>
            <td>{$row['maxmarks']}</td>
            <td>" . number_format($row['percentage'], 2) . "%</td>
        </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No data available</td></tr>";
}

echo '        </tbody>
    </table>
</body>
</html>';
?>
