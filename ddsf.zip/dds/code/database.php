<!-- <?php
	$db_host = 'localhost';
	$db_name = 'quiz';
	$db_user = 'root';
	$db_pass = 'root';
	$conn = new mysqli($db_host,$db_user,$db_pass,$db_name);
	if($conn->connect_error){
		printf("Connect failed: %s\n",$conn->connect_error);
		exit;
	}
?> -->
<?php
$servername = "localhost";
$username = "root";
$password = "root"; // Replace with your actual password
$dbname = "quiz";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
<?php
$servername = "localhost"; // Replace with your DB server
$username = "root"; // Replace with your DB username
$password = "root"; // Replace with your DB password
$dbname = "quiz"; // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
