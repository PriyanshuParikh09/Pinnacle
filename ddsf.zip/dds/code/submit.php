<?php
	session_start();
    if(!isset($_SESSION["studentloggedin"]) || $_SESSION["studentloggedin"] !== true){
      header("location: studentlogin.php");
      exit;
    }
	$rollnumber=$_SESSION["rollnumber"];
    $totalques=$_SESSION["numques"];
    $quiznumber=$_SESSION["quiznumber"];
	include "database.php";
	$sql = "select maxmarks from quizconfig where quiznumber=".$quiznumber.";";
    $result = $conn->query($sql);
	$row = $result->fetch_assoc();
	$maxmarks = $row["maxmarks"];  
	$sql = "insert into result (rollnumber,quiznumber,submit,maxmarks) values (".$rollnumber.",".$quiznumber.",1,".$maxmarks.");";
    $result = $conn->query($sql);    
    $stmt = $conn->prepare("SELECT maxmarks FROM quizconfig WHERE quiznumber = ?");
$stmt->bind_param("i", $quiznumber);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
$maxmarks = $row["maxmarks"];
$stmt->close();
$totalmarks = 0; // Initialize totalmarks
for ($i = 1; $i <= $totalques; $i++) {
    if (isset($_SESSION["q{$i}_correct"]) && $_SESSION["q{$i}_correct"] === true) {
        $totalmarks++; // Increment score for each correct answer
    }
}
$stmt = $conn->prepare("INSERT INTO result (rollnumber, quiznumber, totalmarks, submit, maxmarks) VALUES (?, ?, ?, ?, ?)");
$submit = 1; // Indicating quiz is submitted
$stmt->bind_param("iiiii", $rollnumber, $quiznumber, $totalmarks, $submit, $maxmarks);

if ($stmt->execute()) {
    echo "Score successfully saved!";
} else {
    echo "Error saving score: " . $stmt->error;
}
$stmt->close();

	header("Location: studentlogout.php");
?>